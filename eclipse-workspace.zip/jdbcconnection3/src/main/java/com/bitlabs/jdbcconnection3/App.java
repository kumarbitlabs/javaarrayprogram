package com.bitlabs.jdbcconnection3;
import java.util.Scanner;


public class App 
{
    public static void main( String[] args )
    {
       DaoInterface dao = new DaoImpl();
       Patient p = new Patient();
       Scanner sc= new Scanner(System.in);
       boolean ch=true;
       try {
    	   while(ch)
           {
        	   System.out.println("*******MENU**************");
        	   System.out.println("1.Patient Registration\n2.View All patients\n3.deletePatient by id\n4.updatepatientinfo\n5.getpatientby Id");
        	   System.out.println("enter the choice from the menu:");
        	   int choice=sc.nextInt();
        	   switch(choice)
        	   {
        	      case 1:
        	           System.out.println("enter the patient id");
        	           int id=sc.nextInt();
        	    	   p.setPid(id);
        	    	   System.out.println("enter the patient name");
        	    	   String name=sc.next();
        	           p.setPname(name);
        	           System.out.println("enter the age");
        	           int age=sc.nextInt();
        	           p.setAge(age);
        	           System.out.println("enter the city");
        	           String city=sc.next();
        	           p.setCity(city);
        	           System.out.println("enter the mobile number");
        	           long num=sc.nextLong();
        	           p.setMobile(num);
        	           dao.PatientRegistration(p);
        	    	   break;
        	      
        	    	  
        	      case 2:
        	      
        	    	 dao.viewAllPatients();
        	    	 break;
        	      
        	      case 3:
        	    	  System.out.println("enter the ID of the patient you want to delete");
        	    	  int idn=sc.nextInt();
        	    	  dao.deletePetientById(idn);
        	    	  break;
        	      case 4:
        	    	  System.out.println("enter the patient id you want to update");
       	           int id1=sc.nextInt();
       	    	   p.setPid(id1);
       	    	   System.out.println("enter the patient name");
       	    	   String name1=sc.next();
       	           p.setPname(name1);
       	           System.out.println("enter the age");
       	           int age1=sc.nextInt();
       	           p.setAge(age1);
       	          // System.out.println("enter the city");
       	          // String city1=sc.next();
       	          // p.setCity(city1);
       	          // System.out.println("enter the mobile number");
       	         //  long num1=sc.nextLong();
       	          // p.setMobile(num1);        	    	        	
        	       dao.updatePetientInfo(p);
        	       break;
        	      
        	      case 5:
        	    	  System.out.println("enter the patient id you want to retrieve");
        	    	  int id2=sc.nextInt();
        	    	  dao.getPatientById(id2);
        	    	  break;
        	      default:
        	    	  ch=false;
        	    	  
        	   }      	 
        	   
           }
           System.out.println("operations performed successfully");
           
       }catch(Exception e) {
    	   System.out.println(e);
       }
       
    }
}
