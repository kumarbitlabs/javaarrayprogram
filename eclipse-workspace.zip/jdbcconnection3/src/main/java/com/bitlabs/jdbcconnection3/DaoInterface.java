package com.bitlabs.jdbcconnection3;

public interface DaoInterface {
	public void PatientRegistration(Patient p);
	public void viewAllPatients();
	public void deletePetientById(int pid);
	public void updatePetientInfo(Patient p);
	public void getPatientById(int pid);

}
